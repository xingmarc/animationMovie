Name: Xing Yichi
UID:  804513974

To open my project, go to the directory "Assignment2" and open "Assignment2.xcodeproj"

Description:
Overall story: my code animated a scene in "Lord of the Rings": 
The giant spider "Shelob" capturing Frodo. More refernce of Shelob at: en.wikipedia.org/wiki/Shelob
  
In my animation, I modeled:
a ground
a valley 
a cave
a spider(which is Shelob)
a man(which is Frodo)

For the spider, I animated the movement of all its eight legs
For the detail movement of the legs, I referenced a video in youtube:https://www.youtube.com/watch?v=GtHzpX0FCFY

For the polygons,
I created two polygons, the Hexagon and the Prism.
Both of them have the texture.
The Hexagons are used to model the pillar in the entrance of the cave,
and the prisms are used to model the valley.

The hierarchical objects: 
the legs of the spider.

Objects that have texture:
the body and abdomen of the spider
the valley
the ground
all the parts of the cave




